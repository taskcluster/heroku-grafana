inject
======

Dependency injection for go
