define([
  './alertSrv',
  './utilSrv',
  './datasourceSrv',
  './contextSrv',
  './timer',
  './keyboardManager',
  './analytics',
  './popoverSrv',
  './backendSrv',
],
function () {});
