define([
  './grafanaCtrl',
  './pulldown',
  './search',
  './metricKeys',
  './inspectCtrl',
  './jsonEditorCtrl',
  './loginCtrl',
  './invitedCtrl',
  './signupCtrl',
  './resetPasswordCtrl',
  './sidemenuCtrl',
  './errorCtrl',
], function () {});
