define([
  './datasourcesCtrl',
  './datasourceEditCtrl',
  './orgUsersCtrl',
  './newOrgCtrl',
  './userInviteCtrl',
  './orgApiKeysCtrl',
  './orgDetailsCtrl',
], function () {});
