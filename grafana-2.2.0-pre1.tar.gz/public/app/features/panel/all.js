define([
  './panelMenu',
  './panelDirective',
  './panelSrv',
  './panelHelper',
  './soloPanelCtrl',
], function () {});
