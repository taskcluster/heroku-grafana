package util

type DynMap map[string]interface{}
