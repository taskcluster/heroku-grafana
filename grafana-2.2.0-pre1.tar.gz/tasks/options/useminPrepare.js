module.exports = function(config) {
  return {
    html: [
      'tmp/index.html',
    ]
  };
};
